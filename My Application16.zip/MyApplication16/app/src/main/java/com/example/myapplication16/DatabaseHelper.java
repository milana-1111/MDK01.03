package com.example.myapplication16;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "usercontact.db";
    private static final int SCHEMA = 2;

    static final String TABLE_USERS = "users";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_YEAR = "year";
    public static final String COLUMN_CITY_ID = "city_id";

    static final String TABLE_CITIES = "cities";
    public static final String COLUMN_CITY_NAME = "city_name";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, SCHEMA);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_CITIES + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_CITY_NAME + " TEXT);");

        db.execSQL("INSERT INTO " + TABLE_CITIES + " (" + COLUMN_CITY_NAME + ") VALUES " +
                "('Москва'), ('Санкт-Петербург'), ('Оренбург');");

        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_NAME + " TEXT," +
                COLUMN_YEAR + " INTEGER," +
                COLUMN_CITY_ID + " INTEGER," +
                "FOREIGN KEY(" + COLUMN_CITY_ID + ") REFERENCES " + TABLE_CITIES + "(" + COLUMN_ID + "));");

        db.execSQL("INSERT INTO " + TABLE_USERS + " (" + COLUMN_NAME + ", " + COLUMN_YEAR + ", " + COLUMN_CITY_ID + ") " +
                "VALUES ('Руслан Гамидов', 1978, 1), ('Татьяна Стрелкова', 1992, 2);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CITIES);
        onCreate(db);
    }
}
