package com.example.myapplication16;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SimpleCursorAdapter;
import androidx.appcompat.app.AppCompatActivity;

public class UserActivity extends AppCompatActivity {
    EditText nameBox;
    EditText yearBox;
    Spinner citySpinner;
    Button delButton;
    Button saveButton;
    DatabaseHelper sqlHelper;
    SQLiteDatabase db;
    Cursor userCursor;
    Cursor citiesCursor;
    SimpleCursorAdapter cityAdapter;
    long userId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        nameBox = findViewById(R.id.name);
        yearBox = findViewById(R.id.year);
        citySpinner = findViewById(R.id.citySpinner);
        delButton = findViewById(R.id.deleteButton);
        saveButton = findViewById(R.id.saveButton);

        sqlHelper = new DatabaseHelper(this);
        db = sqlHelper.getWritableDatabase();

        citiesCursor = db.rawQuery("SELECT * FROM " + DatabaseHelper.TABLE_CITIES, null);
        String[] cityHeaders = new String[]{DatabaseHelper.COLUMN_CITY_NAME};
        cityAdapter = new SimpleCursorAdapter(this, android.R.layout.simple_spinner_item,
                citiesCursor, cityHeaders, new int[]{android.R.id.text1}, 0);
        cityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        citySpinner.setAdapter(cityAdapter);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            userId = extras.getLong("id");
        }

        if (userId > 0) {
            userCursor = db.rawQuery("select * from " + DatabaseHelper.TABLE_USERS + " where " + DatabaseHelper.COLUMN_ID + "=?", new String[]{String.valueOf(userId)});
            userCursor.moveToFirst();

            nameBox.setText(userCursor.getString(1));
            yearBox.setText(String.valueOf(userCursor.getInt(2)));

            int cityId = userCursor.getInt(3);
            for (int i = 0; i < cityAdapter.getCount(); i++) {
                if (citiesCursor.moveToPosition(i)) {
                    if (citiesCursor.getLong(0) == cityId) {
                        citySpinner.setSelection(i);
                        break;
                    }
                }
            }
            userCursor.close();
        } else {
            delButton.setVisibility(View.GONE);
        }
    }

    public void save(View view) {
        ContentValues cv = new ContentValues();
        cv.put(DatabaseHelper.COLUMN_NAME, nameBox.getText().toString());
        cv.put(DatabaseHelper.COLUMN_YEAR, Integer.parseInt(yearBox.getText().toString()));

        long selectedCityId = 0;
        if (citySpinner.getSelectedItem() != null) {
            Cursor selectedCursor = (Cursor) citySpinner.getSelectedItem();
            selectedCityId = selectedCursor.getLong(0);
        }
        cv.put(DatabaseHelper.COLUMN_CITY_ID, selectedCityId);

        if (userId > 0) {
            db.update(DatabaseHelper.TABLE_USERS, cv, DatabaseHelper.COLUMN_ID + "=" + userId, null);
        } else {
            db.insert(DatabaseHelper.TABLE_USERS, null, cv);
        }
        goHome();
    }

    public void delete(View view) {
        db.delete(DatabaseHelper.TABLE_USERS, "_id= ?", new String[]{String.valueOf(userId)});
        goHome();
    }

    private void goHome() {
        db.close();
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (citiesCursor != null) citiesCursor.close();
    }
}