package com.example.videorecorderapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.Toast;
import android.widget.VideoView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private VideoView videoView;
    private ActivityResultLauncher<Intent> videoCaptureLauncher;
    private Uri videoUri = null; // Сохраняем URI записанного видео для управления

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        videoView = findViewById(R.id.videoView);
        Button btnRecord = findViewById(R.id.btnRecordVideo);
        Button btnPlay = findViewById(R.id.btnPlay);
        Button btnPause = findViewById(R.id.btnPause);
        Button btnStop = findViewById(R.id.btnStop);

        // Регистрация лаунчера для получения результата из системной камеры
        videoCaptureLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        videoUri = result.getData().getData();
                        if (videoUri != null) {
                            videoView.setVideoURI(videoUri);
                            videoView.start();
                            Toast.makeText(this, "Видео записано и воспроизводится", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(this, "Запись отменена", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        // Обработчик кнопки записи
        btnRecord.setOnClickListener(v -> dispatchTakeVideoIntent());

        // Самостоятельная работа: кнопки управления воспроизведением
        btnPlay.setOnClickListener(v -> {
            if (videoUri != null) {
                videoView.start();
            } else {
                Toast.makeText(this, "Сначала запишите видео!", Toast.LENGTH_SHORT).show();
            }
        });

        btnPause.setOnClickListener(v -> {
            if (videoView.isPlaying()) {
                videoView.pause();
            }
        });

        btnStop.setOnClickListener(v -> {
            videoView.stopPlayback();
            if (videoUri != null) {
                videoView.setVideoURI(videoUri); // Сброс на начало
            }
        });
    }

    private void dispatchTakeVideoIntent() {
        Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        if (takeVideoIntent.resolveActivity(getPackageManager()) != null) {
            videoCaptureLauncher.launch(takeVideoIntent);
        } else {
            Toast.makeText(this, "На устройстве нет приложения камеры", Toast.LENGTH_SHORT).show();
        }
    }
}