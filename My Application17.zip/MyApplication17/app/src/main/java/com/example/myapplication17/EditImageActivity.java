package com.example.myapplication17;

import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class EditImageActivity extends AppCompatActivity {

    private ImageView imageView;
    private Matrix matrix = new Matrix();
    private Bitmap currentBitmap;
    private Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_image);

        Init();
    }

    private void Init() {
        imageView = findViewById(R.id.imageView);
        btnSave = findViewById(R.id.btnSave);
        Button btnFlipH = findViewById(R.id.btnFlipH);
        Button btnFlipV = findViewById(R.id.btnFlipV);
        Button btnRotateL = findViewById(R.id.btnRotateL);
        Button btnRotateR = findViewById(R.id.btnRotateR);
        Button btnGrayscale = findViewById(R.id.btnGrayscale);

        Intent intent = getIntent();
        if (intent != null && intent.getData() != null) {
            try {
                Uri imageUri = intent.getData();
                InputStream inputStream = getContentResolver().openInputStream(imageUri);
                currentBitmap = BitmapFactory.decodeStream(inputStream);
                imageView.setImageBitmap(currentBitmap);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        btnFlipH.setOnClickListener(v -> applyTransformation(-1.0f, 1.0f, 0));
        btnFlipV.setOnClickListener(v -> applyTransformation(1.0f, -1.0f, 0));
        btnRotateL.setOnClickListener(v -> applyTransformation(1.0f, 1.0f, -90));
        btnRotateR.setOnClickListener(v -> applyTransformation(1.0f, 1.0f, 90));

        btnGrayscale.setOnClickListener(v -> applyGrayscaleFilter());

        // Привязка кнопки сохранения
        btnSave.setOnClickListener(v -> saveImageToGallery());
    }

    private void applyTransformation(float scaleX, float scaleY, float degrees) {
        if (currentBitmap != null) {
            matrix.reset();

            if (scaleX != 1.0f || scaleY != 1.0f) {
                matrix.preScale(scaleX, scaleY);
            }
            if (degrees != 0) {
                matrix.preRotate(degrees);
            }

            Bitmap newBitmap = Bitmap.createBitmap(
                    currentBitmap, 0, 0,
                    currentBitmap.getWidth(), currentBitmap.getHeight(),
                    matrix, true
            );

            currentBitmap = newBitmap;
            imageView.setImageBitmap(currentBitmap);
        }
    }

    private void applyGrayscaleFilter() {
        if (currentBitmap != null) {
            ColorMatrix colorMatrix = new ColorMatrix();
            colorMatrix.setSaturation(0);

            ColorMatrixColorFilter filter = new ColorMatrixColorFilter(colorMatrix);
            imageView.setColorFilter(filter);
        }
    }

    private void saveImageToGallery() {
        if (currentBitmap == null) {
            Toast.makeText(this, "Нет изображения для сохранения", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            Bitmap bitmapToSave = getBitmapWithFilter();

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, "EditedPhoto_" + System.currentTimeMillis() + ".jpg");
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/EditedPhotos");

                Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (uri != null) {
                    OutputStream outputStream = getContentResolver().openOutputStream(uri);
                    bitmapToSave.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                    outputStream.close();

                    Toast.makeText(this, "Изображение сохранено в галерею", Toast.LENGTH_SHORT).show();
                }
            } else {
                File directory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
                File editedPhotosDir = new File(directory, "EditedPhotos");
                if (!editedPhotosDir.exists()) {
                    editedPhotosDir.mkdirs();
                }

                String fileName = "EditedPhoto_" + System.currentTimeMillis() + ".jpg";
                File file = new File(editedPhotosDir, fileName);

                FileOutputStream outputStream = new FileOutputStream(file);
                bitmapToSave.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                outputStream.close();

                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DATA, file.getAbsolutePath());
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

                Toast.makeText(this, "Изображение сохранено в галерею", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Ошибка сохранения: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private Bitmap getBitmapWithFilter() {
        Bitmap resultBitmap = Bitmap.createBitmap(
                currentBitmap.getWidth(),
                currentBitmap.getHeight(),
                Bitmap.Config.ARGB_8888
        );

        Canvas canvas = new Canvas(resultBitmap);
        Paint paint = new Paint();

        ColorMatrix colorMatrix = new ColorMatrix();
        colorMatrix.setSaturation(0);
        ColorMatrixColorFilter filter = new ColorMatrixColorFilter(colorMatrix);

        if (imageView.getColorFilter() != null) {
            paint.setColorFilter(filter);
        }

        canvas.drawBitmap(currentBitmap, 0, 0, paint);

        return resultBitmap;
    }
}