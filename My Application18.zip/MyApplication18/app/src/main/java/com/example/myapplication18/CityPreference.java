package com.example.myapplication18;

import android.app.Activity;
import android.content.SharedPreferences;

public class CityPreference {
    private SharedPreferences prefs;

    public CityPreference(Activity activity) {
        prefs = activity.getPreferences(Activity.MODE_PRIVATE);
    }

    String getCity() {
        return prefs.getString("city", "Orenburg");
    }

    void setCity(String city) {
        prefs.edit().putString("city", city).commit();
    }
}
