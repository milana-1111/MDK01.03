package com.example.myapplication18;

import android.content.Context;
import android.os.Handler;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ConnectFetch {
    private static final String OPEN_WEATHER_MAP_API =
            "https://api.openweathermap.org/data/2.5/weather?q=%s&appid=%s&units=metric";
    private static final String OPEN_WEATHER_ICON =
            "https://openweathermap.org/img/wn/%s@2x.png";

    private OnConnectionCompleteListener listener;
    private Handler handler;

    public interface OnConnectionCompleteListener {
        void onSuccess(JSONObject response);
        void onFail(String message);
    }

    public ConnectFetch(Context context, String city, OnConnectionCompleteListener listener) {
        this.listener = listener;
        this.handler = new Handler();
        updateWeatherData(city, context);
    }

    private void updateWeatherData(final String city, final Context context) {
        new Thread() {
            public void run() {
                final JSONObject json = getJSON(context, city);
                if (json == null) {
                    handler.post(new Runnable() {
                        public void run() {
                            if (listener != null) listener.onFail(city);
                        }
                    });
                } else {
                    handler.post(new Runnable() {
                        public void run() {
                            if (listener != null) listener.onSuccess(json);
                        }
                    });
                }
            }
        }.start();
    }

    public static JSONObject getJSON(Context context, String city) {
        try {
            String urlString = String.format(OPEN_WEATHER_MAP_API,
                    city, context.getString(R.string.weather_api_key));
            URL url = new URL(urlString);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.addRequestProperty("x-api-key", context.getString(R.string.weather_api_key));
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(connection.getInputStream()));
            StringBuffer json = new StringBuffer(1024);
            String tmp = "";
            while ((tmp = reader.readLine()) != null)
                json.append(tmp).append("\n");
            reader.close();
            JSONObject data = new JSONObject(json.toString());
            if (data.getInt("cod") != 200) {
                return null;
            }
            return data;
        } catch (Exception e) {
            return null;
        }
    }

    public static String getIconUrl(JSONObject json) {
        try {
            JSONObject details = json.getJSONArray("weather").getJSONObject(0);
            String icon = details.getString("icon");
            return String.format(OPEN_WEATHER_ICON, icon);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
}

