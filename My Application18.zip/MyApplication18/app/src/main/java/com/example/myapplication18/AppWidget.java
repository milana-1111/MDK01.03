package com.example.myapplication18;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.RemoteViews;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.AppWidgetTarget;
import org.json.JSONObject;
import java.util.Arrays;

public class AppWidget extends AppWidgetProvider {
    final static String LOG_TAG = "myLogs";

    static void updateAppWidget(final Context context, SharedPreferences sharedPreferences,
                                AppWidgetManager appWidgetManager, final int appWidgetId) {

        String widgetCity = sharedPreferences.getString(ConfigActivity.WIDGET_CITY + appWidgetId, "Orenburg");
        final RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.app_widget);
        remoteViews.setTextViewText(R.id.city_field, widgetCity);

        Intent intent = new Intent(context, ConfigActivity.class);
        intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, appWidgetId, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        remoteViews.setOnClickPendingIntent(R.id.btn_change_city, pendingIntent);

        new ConnectFetch(context, widgetCity, new ConnectFetch.OnConnectionCompleteListener() {
            @Override
            public void onSuccess(JSONObject response) {
                renderWeather(response, context, remoteViews, appWidgetId);
            }

            @Override
            public void onFail(String message) {
                remoteViews.setTextViewText(R.id.details_field, "Ошибка связи");
                appWidgetManager.updateAppWidget(appWidgetId, remoteViews);
            }
        });
    }

    public static void renderWeather(JSONObject json, Context context, RemoteViews remoteViews, int appWidgetId) {
        try {
            // Получаем URL иконки погоды
            String iconUrl = ConnectFetch.getIconUrl(json);

            // Устанавливаем текст температуры
            remoteViews.setTextViewText(R.id.details_field, StaticWeatherAnalyze.getTemperatureField(json));

            // Создаем AppWidgetTarget для Glide 4
            AppWidgetTarget appWidgetTarget = new AppWidgetTarget(
                    context.getApplicationContext(),
                    R.id.weather_icon,
                    remoteViews,
                    appWidgetId
            );

            // Загружаем иконку асинхронно через Glide 4
            Glide.with(context.getApplicationContext())
                    .asBitmap()
                    .load(iconUrl)
                    .into(appWidgetTarget);

            pushWidgetUpdate(context, remoteViews);
        } catch (Exception e) {
            Log.e("SimpleWeather", "JSON field error");
        }
    }

    public static void pushWidgetUpdate(Context context, RemoteViews rv) {
        ComponentName myWidget = new ComponentName(context, AppWidget.class);
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        manager.updateAppWidget(myWidget, rv);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        SharedPreferences sp = context.getSharedPreferences(ConfigActivity.WIDGET_PREF, Context.MODE_PRIVATE);
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, sp, appWidgetManager, appWidgetId);
        }
        Log.d(LOG_TAG, "onUpdate " + Arrays.toString(appWidgetIds));
    }

    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        super.onDeleted(context, appWidgetIds);
        SharedPreferences.Editor editor = context.getSharedPreferences(ConfigActivity.WIDGET_PREF, Context.MODE_PRIVATE).edit();
        for (int widgetID : appWidgetIds) {
            editor.remove(ConfigActivity.WIDGET_CITY + widgetID);
        }
        editor.apply();
        Log.d(LOG_TAG, "onDeleted " + Arrays.toString(appWidgetIds));
    }

    @Override
    public void onEnabled(Context context) {
        Log.d(LOG_TAG, "onEnabled");
    }

    @Override
    public void onDisabled(Context context) {
        Log.d(LOG_TAG, "onDisabled");
    }
}
