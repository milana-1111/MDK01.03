package com.example.myapplication13;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View v) {
        EditText nameText = findViewById(R.id.name);
        EditText companyText = findViewById(R.id.company);
        EditText ageText = findViewById(R.id.age);
        EditText phoneText = findViewById(R.id.phone);

        String name = nameText.getText().toString().trim();
        String company = companyText.getText().toString().trim();
        String ageStr = ageText.getText().toString().trim();
        String phone = phoneText.getText().toString().trim();

        boolean hasError = false;

        if (name.isEmpty()) {
            nameText.setError("Введите имя!");
            hasError = true;
        } else {
            nameText.setError(null);
        }

        if (phone.isEmpty()) {
            phoneText.setError("Введите телефон!");
            hasError = true;
        } else {
            phoneText.setError(null);
        }

        if (hasError) {
            return;
        }


        int age = 0;
        if (!ageStr.isEmpty()) {
            age = Integer.parseInt(ageStr);
        }

        User user = new User(name, company, age, phone);
        Intent intent = new Intent(MainActivity.this, SecondActivity.class);
        intent.putExtra(User.class.getSimpleName(), user);
        startActivity(intent);
    }
}



