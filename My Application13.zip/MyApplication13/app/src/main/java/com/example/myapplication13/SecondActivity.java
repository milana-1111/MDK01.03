package com.example.myapplication13;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView textView = new TextView(this);
        textView.setTextSize(26);
        textView.setPadding(16, 16, 16, 16);

        Bundle arguments = getIntent().getExtras();
        if (arguments != null) {
            // Получаем наш объект User
            User user = arguments.getParcelable(User.class.getSimpleName());

            if (user != null) {
                String info = "Имя: " + user.getName() +
                        "\nОрганизация: " + user.getCompany() +
                        "\nВозраст: " + user.getAge() +
                        "\nТелефон: " + user.getPhone();
                textView.setText(info);
            }
        }
        setContentView(textView);
    }
}


